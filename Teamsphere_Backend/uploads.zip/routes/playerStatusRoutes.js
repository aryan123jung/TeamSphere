const express = require('express');
const {
    createPlayerStats,
    getPlayerStatsByPlayerId,
    getAllPlayerStats,
    updatePlayerStats,
    deletePlayerStats
} = require('../controllers/playerStatusController');

const router = express.Router();

// Create player stats
router.post('/create', createPlayerStats);

// Get all stats for a specific player
router.get('/:playerId', getPlayerStatsByPlayerId);

// Get stats for all players
router.get('/', getAllPlayerStats);

// Update player stats
router.put('/:stat_id', updatePlayerStats);

// Delete player stats
router.delete('/:stat_id', deletePlayerStats);

module.exports = router;
